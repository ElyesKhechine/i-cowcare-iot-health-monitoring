Todo
===========

Add SPI support
